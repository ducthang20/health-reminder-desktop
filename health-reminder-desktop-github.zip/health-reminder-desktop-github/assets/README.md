# Assets

Đặt file `icon.ico` của bạn vào thư mục này.

File icon.ico phải chứa các kích thước: 16x16, 32x32, 48x48, 256x256
